﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;

using System.Data.OleDb;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading;
using System.Transactions;
using Microsoft.Office.Tools.Ribbon;
using System.Windows.Forms;
//using Microsoft.Office.Interop.Excel;
//using Microsoft.Office.Tools.Ribbon;


namespace ExcelAddIn5
{
    public partial class Ribbon1
    {
        //Workbooks wbook = Globals.ThisAddIn.Application.Workbooks; //当前活动workbook
        //string filepath = Globals.ThisAddIn.Application.ActiveWorkbook.FullName;

        #region 全局变量
        DataSet ds;
        string[] tablenames;
        SqlConnection conn;
        string connstr;
        List<SqlBulkCopyColumnMapping> SqlBulkCopyparameters;
        //string filepath = Globals.ThisAddIn.Application.ActiveWorkbook.FullName;
        #endregion
        private void Ribbon1_Load(object sender, RibbonUIEventArgs e)
        {
            
            
        }

        private bool IsHave(string PART_ID)
        {
            string sql = string.Format("select TOP 1 *  from Data WHERE PART_ID='{0}'", PART_ID);
            DataTable dt = SqlHelper.GetBySQL(sql);
            return dt.Rows.Count > 0 ? true : false;
        }
        private void button1_Click(object sender, RibbonControlEventArgs e)
        {
            string filepath = Globals.ThisAddIn.Application.ActiveWorkbook.FullName;
            MessageBox.Show(filepath);

        }

        #region 自定义方法
        /// <summary>
        /// 读取Excel
        /// </summary>
        /// <param name="filename">文件名(含格式)</param>
        /// <param name="index">页数(默认0:第一页)</param>
        void ReadExcel(string filename, int index)
        {
            using (OleDbConnection conn = new OleDbConnection(@"Provider=Microsoft.Jet.OLEDB.4.0;Data Source=" + filename + ";" + "Extended Properties=Excel 8.0;"))
            {
                conn.Open();
                System.Data.DataTable table = conn.GetOleDbSchemaTable(OleDbSchemaGuid.Tables, null);
                tablenames = new string[table.Rows.Count];
                for (int i = 0; i < table.Rows.Count; i++) tablenames[i] = table.Rows[i][2].ToString();//获取Excel的表名
                if (tablenames.Length <= 0)
                { MessageBox.Show("Excel中没有表!"); return; }
                using (OleDbCommand cmd = conn.CreateCommand())
                {
                    //lb_tablename.Text = "表名:" + tablenames[index].Substring(0, tablenames[index].Length - 1);
                    cmd.CommandText = "select * from [" + tablenames[index] + "]";
                    ds = new DataSet();
                    using (OleDbDataAdapter da = new OleDbDataAdapter(cmd))
                    {
                        da.Fill(ds, tablenames[index]);
                        //移除第一行
                        ds.Tables[0].Rows.RemoveAt(0);
                        //移除最后一行
                        ds.Tables[0].Rows.RemoveAt(ds.Tables[0].Rows.Count - 1);
                    }
                }
            }
        }
        #endregion

        private void btn_import_Click(object sender, Microsoft.Office.Tools.Ribbon.RibbonControlEventArgs e)
        {

            //Thread fThread = new Thread(new ThreadStart(Import));
            //fThread.Start()
            try
            {
                string filepath = Globals.ThisAddIn.Application.ActiveWorkbook.FullName;
                ReadExcel(filepath, 0);
                using (TransactionScope transction = new TransactionScope())
                {
                    DataTable dt = ds.Tables[0];
                    for (int i = 0; i < dt.Rows.Count; i++)
                    {
                        string PART_ID = dt.Rows[i][0].ToString();
                        string PART_NO = dt.Rows[i][1].ToString();
                        decimal RESIDUAL_OIL_LEVEL = 0;
                        if (dt.Rows[i][4] is DBNull)
                        {
                            RESIDUAL_OIL_LEVEL = 0;
                        }
                        else
                        {
                            RESIDUAL_OIL_LEVEL = Convert.ToDecimal(dt.Rows[i][4]);
                        }
                        if (!IsHave(PART_ID))
                        {
                            int result = SqlHelper.ExecuteNoQuery("insert into [Data](PART_ID,PART_NO,RESIDUAL_OIL_LEVEL) values(@PART_ID,@PART_NO,@RESIDUAL_OIL_LEVEL )", new SqlParameter("@PART_ID", PART_ID), new SqlParameter("@PART_NO", PART_NO), new SqlParameter("@RESIDUAL_OIL_LEVEL", RESIDUAL_OIL_LEVEL));

                        }
                        else
                        {
                            MessageBox.Show("数据库中已经存在该记录:" + PART_ID);
                            return;
                        }
                    }
                    MessageBox.Show("成功导入" + dt.Rows.Count + "条数据");
                    transction.Complete();
                }
            }

            catch (Exception ex)
            {
                MessageBox.Show(ex.ToString());
            }
        }

       
    
    }
}
            
        

       
        


    

